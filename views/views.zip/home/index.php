<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Desa Banjarwaru</title>
        <link rel="icon" type="image/x-icon" href="<?=get_foto('/public_style/front/assets/img/favicon.ico')?>" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <!-- <link href="css/styles.css" rel="stylesheet" /> -->

        <link rel="stylesheet" href="<?php echo get_template_directory('front/vendor/OwlCarousel2/dist/assets/owl.carousel.min.css') ;?>">
        <link rel="stylesheet" href="<?php echo get_template_directory('front/vendor/OwlCarousel2/dist/assets/owl.theme.default.min.css') ;?>">

        <link rel="stylesheet" href="<?php echo get_template_directory('front/css/styles.css') ;?>">
    </head>

    <!-- <style type="text/css">
        .card {
padding-left: 20px;
padding-right: 20px;
box-shadow: 0 0px 20px 0 rgba(0,0,0,0.2);
background-color: rgba(0,0,0,0.2);
transition: 0.3s;}
    </style> -->

    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="<?=get_foto('/public_style/front/assets/img/navbar-logo.svg')?>" alt="" /></a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ml-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ml-auto">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#services">Tentang</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#visimisi">Visi & Misi</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#portfolio">Berita</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#contact">Contact</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="<?=base_url('kampung_online')?>">Kampung Online</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container">
                <div class="masthead-subheading">Selamat Datang di Desa Banjarwaru!</div>
                <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Lebih Lanjut</a>
            </div>
        </header>
        <!-- Services-->
        <section class="page-section" id="services">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Tentang Desa Banjarwaru</h2><hr>
                    <h3 class="section-subheading text-muted">Desa Banjarwaru merupakan salah satu Desa di Wilayah Kecamatan Ciawi Kabupaten Bogor, dengan luas Wilayah 128, 5Ha, diatas permukaan Laut 450M dan tinggi curah Hujan 120M3, yang terbagi dalam 2 (Dua) Dusun, 10 (Sepuluh) RukunWarga(RW), dan 35 (Tiga puluh lima) Rukun Tetangga (RT)</h3>
                </div>
                <div class="row">
                    <div class="col-md-6 text-center">
                        <img src="<?=get_foto_assets('bill.png')?>" class="img-fluid w-50 mb-3" style="border-radius: 15px;">
                    </div>
                    <div class="col-md-6">
                        <h3>Bapak Abdul Rahman</h3><hr>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    </div>
                </div>
            </div>
        </section>

        <section class="page-section" id="visimisi">
            <div class="container">
                <div>
                    <h2 class="section-heading text-uppercase text-center">VISI & MISI</h2><hr>
                    <h5><b>VISI</b></h5><p>Mewujudkan Banjarwaru mampu memberdayakan potensi yang ada dan tersedia menuju masyarakat yang agamis, berbudaya, maju, damai, mandiri, adil dan sejahtera</p><br>
                    <h5><b>MISI</b></h5>
                    <p>
                        <ul>
                            <li>Mendorong peningkatan kesadaran dan penghayatan nilai-nilai ajaran agama yang menghargai keberagaman</li>
                            <li>Meningkatkan kualitas sumberdaya masyarakat dan aparatur pemerintah desa untuk mempercepat pembangunan di tingkat desa</li>
                            <li>Meningkatkan kesejahteraan masyarakat dan mengurangi pengangguran dan penduduk miskin</li>
                            <li>Mendorong masyarakat,mengembangkan usahanya melalu pembinaan yang terprogram dan bekerjasama dengan instansi terkait</li>
                            <li>Mendorong terwujudnya sitem dan kesadaran humu yang mendukung tegaknya supermasi hukum dan hak asasi manusia (ham)</li>
                            <li>Mendorong terciptanya wawasan kebangsaan dan sistem keamanan dan ketertiban</li>
                            <li>Mengembangkan kapasitas kelembagaan pemerintah, swasta dan masyarakat agar lebih berperan aktif dalam mensukseskan penyelenggaraan pemerintahan pelaksanaan pembangunan dan pelayanan masyarakat</li>
                            <li>Mewujudkan aparatur pemerintahan desa yang bersih dan berwibawa</li>
                            <li>Mewujudkan pembangunan yang berwawasan lingkungan dan melindungi masyarakat dari bencana alam</li>
                            <li>Meningkatkan dan mengembangkan pemanfaatan potensi sumber daya alam secara optimal dan berkelanjutan</li>
                        </ul>
                    </p><br>
                </div>
            </div>
        </section>
        <!-- Portfolio Grid-->
        <section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Berita</h2><hr>
                </div>
                <div class="row">
                    <div class="owl-carousel owl-three">
                        <?php foreach ($berita as $key => $value): ?>
                            <div class="card ml-2 mr-2">
                              <img class="card-img-top" src="<?=$value['img_cover']?>" alt="Card image cap">
                              <div class="card-body">
                                <h5 class="card-title"><?=$value['title']['rendered']?></h5>
                                <p class="card-text"><?=tgl_ina($value['date'])?></p>
                                <a href="#" class="btn btn-primary">Detail</a>
                              </div>
                            </div>
                        <?php endforeach ?>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact-->
        <section class="page-section" id="contact">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Contact Us</h2>
                    <h3 class="section-subheading text-muted">Hubungi kami langsung via Whatsapp</h3>
                </div>
                <center>
                    <button class="btn btn-success btn-lg" style="border-radius: 30px;"><i class="fab fa-whatsapp"></i> CHAT WHATSAPP</button>
                </center>
            </div>
        </section>
        <!-- Footer-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-left">Copyright © Your Website 2020</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-right">
                        <a class="mr-3" href="#!">Privacy Policy</a>
                        <a href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>

        

        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- Contact form JS-->

        <script src="<?php echo get_template_directory('front/vendor/OwlCarousel2/dist/owl.carousel.min.js') ;?>"></script>

        <!-- <script src="assets/mail/jqBootstrapValidation.js"></script> -->
        <script src="<?php echo get_template_directory('front/assets/mail/jqBootstrapValidation.js') ;?>"></script>
        <!-- <script src="assets/mail/contact_me.js"></script> -->
        <script src="<?php echo get_template_directory('front/assets/mail/contact_me.js') ;?>"></script>
        <!-- Core theme JS-->
        <!-- <script src="js/scripts.js"></script> -->
        <script src="<?php echo get_template_directory('front/js/scripts.js') ;?>"></script>

        <script type="text/javascript">
            $(document).ready(function(){
              $(".owl-one").owlCarousel({
                items : 1,
                loop : 1
              });
            });

            $(document).ready(function(){
              $(".owl-two").owlCarousel({
                items : 3,
                loop : 1
              });
            });

            $(document).ready(function(){
              $(".owl-three").owlCarousel({
                items : 4,
                loop : 1,
                responsive:{
                      0:{
                          items:1
                      },
                      600:{
                          items:2
                      },
                      1000:{
                          items:4
                      }
                  }
              });
            });
        </script>
    </body>
</html>
