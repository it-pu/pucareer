<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Pecorine extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function index_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['no_hp'])) 
		{
			$getuser = $this->Custom_model->getdetail('tbl_user', array('no_hp_user' => $post['no_hp']));

			$this->response([
				    'status' => 'true',
	                'data' => array('id_user' => $getuser['id_user'])
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => array('id_user' => '')
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function saldo_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$getsaldo = $this->Custom_model->getdetail('tbl_user', array('id_user' => $post['id_user']));

		$this->response([
				    'status' => 'true',
	                'data' => array('saldo_user' => 'Rp '.$getsaldo['saldo_user'])
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function lok_desa_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$lok = $this->Custom_model->getdetail('tbl_desa', array('id_desa' => $post['id_desa']));

		$this->response([
				    'status' => 'true',
	                'data' => array('latitude' => $lok['latitude_desa'], 'longitude' => $lok['longitude_desa'])
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}
}