<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Bank_sampah extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function daftar_jenis_sampah_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$data = $this->Custom_model->getdata('tbl_jenis_sampah', array('id_desa' => $post['id_desa']));

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function lokasi_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$data = $this->Custom_model->getdata('tbl_lokasi_bs', array('id_desa' => $post['id_desa']));

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function saldo_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$getsaldo = $this->Custom_model->getdetail('tbl_user', array('id_user' => $post['id_user']));

		$this->response([
				    'status' => 'true',
	                'data' => array('saldo_user' => 'Rp '.$getsaldo['saldo_user'])
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function transaksi_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$data = $this->Custom_model->gettransaksiandro($post['id_user']);

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function reward_post()
	{
		$post = $this->input->post(null, true);

		$reward = $this->Custom_model->getrewardandro($post['id_desa']);

		$this->response([
				    'status' => 'true',
	                'data' => $reward
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function trans_reward_post()
	{
		$post = $this->input->post(null, true);

		$reward = $this->Custom_model->getrewardtransandro($post['id_user']);

		$this->response([
				    'status' => 'true',
	                'data' => $reward
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function ambil_reward_post()
	{
		$post = $this->input->post(null, true);

		$getsaldo = $this->Custom_model->getdetail('tbl_user', array('id_user' => $post['id_user']));
		$getreward = $this->Custom_model->getdetail('tbl_reward_bs', array('id_reward_bs' => $post['id_reward_bs']));
		$ttlnilai = $post['qty'] * $getreward['nilai_dibutuhkan'];

		if ($getsaldo['saldo_user'] >= $ttlnilai) 
		{
			$insert = array
				(
					'id_desa' => $post['id_desa'],
					'id_user' => $post['id_user'],
					'id_reward_bs' => $post['id_reward_bs'],
					'qty_get_reward' => $post['qty'],
					'total_nilai' => $ttlnilai,
					'status_transaksi_reward' => 'diklaim',
					'tgl_klaim_reward' => date('Y-m-d H:i:s')
				);

			$id_trans = $this->Custom_model->insertdata('tbl_transaksi_reward_bs', $insert);

			$newqty = $getreward['qty_reward'] - 1;
			$newsaldo = $getsaldo['saldo_user'] - $getreward['nilai_dibutuhkan'];

			$this->Custom_model->updatedata('tbl_reward_bs', array('qty_reward' => $newqty), array('id_reward_bs' => $post['id_reward_bs']));
			$this->Custom_model->updatedata('tbl_user', array('saldo_user' => $newsaldo), array('id_user' => $post['id_user']));

			$this->response([
					    'status' => 'true',
		                'data' => 'Claim Success'
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'Saldo tidak cukup'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}
}