<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Surat extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function index_get()
	{
		$data = $this->Custom_model->getdata('tbl_surat_kategori');

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function list_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_user'])) 
		{
			$data = $this->Custom_model->getsuratuser($post['id_user']);

			if (!empty($data)) 
			{
				$this->response([
					    'status' => 'true',
		                'data' => $data
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
					    'status' => 'true',
		                'data' => array()
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'No user found'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function list_warga_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_user'])) 
		{
			$getrt = $this->Custom_model->getdetail('tbl_rt', array('id_user'));
			$data = $this->Custom_model->getsuratuserwarga($getrt['id_rt']);

			if (!empty($data)) 
			{
				$this->response([
					    'status' => 'true',
		                'data' => $data
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
					    'status' => 'true',
		                'data' => array()
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'No user found'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function index_post()
	{
		$this->load->library('upload');
		$post = $this->input->post(NULL, TRUE);

		$this->form_validation->set_rules('id_desa', 'ID Desa', 'required');
		$this->form_validation->set_rules('id_user', 'ID User', 'required');

		if(empty($post['id_user_bersangkutan']))
		{
			$penanggung_jawab = 0;
		}
		else
		{
			$penanggung_jawab = $post['id_user_bersangkutan'];
		}

		$this->form_validation->set_rules('id_surat_kategori', 'ID Surat Kategori', 'required');
		$this->form_validation->set_rules('nama_surat', 'Nama Surat', 'required');

		if ($this->form_validation->run() == TRUE && !empty($_FILES['file_syarat']))
        {
            $insert = array
				(
					'id_desa' => $post['id_desa'],
					'id_user_penanggung_jawab' => $penanggung_jawab,
					'id_user_bersangkutan' => $post['id_user'],
					'id_surat_kategori' => $post['id_surat_kategori'],
					'id_surat_kategori_sub' => $post['id_surat_kategori_sub'],
					'nama_surat' => $post['nama_surat'],
					'note_surat' => $post['note_surat'],
					'tgl_request' => date('Y-m-d H:i:s'),
					'status_surat' => 'requested'
				);

			$db = $this->Custom_model->post_surat($insert, $_FILES['file_syarat']);

			if ($db === TRUE) 
			{
				$this->response([
				    'status' => 'true',
	                'data' => 'Sukses, data akan ditinjau oleh petugas'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
				    'status' => 'false',
	                'data' => 'Mohon periksa data Anda'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
        }
        else
        {
                $this->response([
				    'status' => 'false',
	                'data' => 'Error, please try again'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
        }
	}
}