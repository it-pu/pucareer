<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Laporan extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function new_post()
	{
		$this->load->library('upload');
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_desa'] && !empty($post['id_user']))) 
		{
			$insert = array
					(
						'id_desa' => $post['id_desa'],
						'id_user' => $post['id_user'],
						'id_laporan_kategori' => $post['id_kategori'],
						'nama_laporan' => $post['nama_laporan'],
						'deskripsi_laporan' => $post['deskripsi_laporan'],
						'tgl_upload_laporan' => date('Y-m-d H:i:s'),
						'status_laporan' => 'diterima'
					);
			$id = $this->Custom_model->insertdata('tbl_laporan', $insert);

			$error = 0;
			foreach ($_FILES['foto_laporan']["name"] as $kkey => $kvalue) 
			{	
				//UPLOAD PRODUK FOTO
				if (!empty($kvalue)) 
				{ 
					$_FILES['file']['name']     = $_FILES['foto_laporan']['name'][$kkey];
				    $_FILES['file']['type']     = $_FILES['foto_laporan']['type'][$kkey];
				    $_FILES['file']['tmp_name'] = $_FILES['foto_laporan']['tmp_name'][$kkey];
				    $_FILES['file']['error']     = $_FILES['foto_laporan']['error'][$kkey];
				    $_FILES['file']['size']     = $_FILES['foto_laporan']['size'][$kkey];

					//MENGEDIT CONFIG UNTUK UPLOAD FOTO
					$config['file_name'] = uniqid().".".get_ext($_FILES['foto_laporan']['name'][$kkey]);
					$config['upload_path'] = './files/lap';
					$config['allowed_types'] = 'jpg|jpeg|png';
					
					//MENGUPLOAD FOTO
					$this->upload->initialize($config);
					if ($this->upload->do_upload('file')) 
					{
						$gbr = $this->upload->data();
		                //Compress Image
		                $config['image_library']='gd2';
		            	$config['source_image']='./files/lap/'.$gbr['file_name'];
		            	$config['new_image']= './files/lap/'.$gbr['file_name'];
		            	$link_file = 'files/lap/'.$config['file_name'];

		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= TRUE;
		                $config['width']= 800;
		                $config['height']= 800;

		                $this->load->library('image_lib', $config);
		                $this->image_lib->resize();

		                $insertfot = array
		                			(
		                				'id_laporan' => $id,
		                				'link_file_laporan_foto' => $link_file
		                			);

		                $id_foto_pro = $this->Custom_model->insertdata('tbl_laporan_foto', $insertfot);
					}
					else
					{
						$error = $this->upload->display_errors();
					}
				}
			}

			$this->response([
				    'status' => 'true',
	                'data' => 'Submit Success'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'Please Check your Data'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function list_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$data = $this->Custom_model->getdata('tbl_laporan', array('id_user' => $post['id_user']));

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function kategori_post()
	{
		$post = $this->input->post(NULL, TRUE);
		$data = $this->Custom_model->getdata('tbl_laporan_kategori', array('id_desa' => $post['id_desa']));

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}
}