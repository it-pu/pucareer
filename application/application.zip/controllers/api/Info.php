<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Info extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function covid_get()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'covid'));
		
		$this->response([
				    'status' => 'true',
	                'data' => $detail
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function anggaran_get()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'anggaran'));
		
		$this->response([
				    'status' => 'true',
	                'data' => $detail
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function bansos_get()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'bansos'));
		
		$this->response([
				    'status' => 'true',
	                'data' => $detail
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function umkm_get()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'umkm'));
		
		$this->response([
				    'status' => 'true',
	                'data' => $detail
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function dpt_get()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'dpt'));
		
		$this->response([
				    'status' => 'true',
	                'data' => $detail
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function profil_desa_get()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'profil_desa'));
		
		$this->response([
				    'status' => 'true',
	                'data' => $detail
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}
}