<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Kemajuan_desa extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function get_kegiatan_get()
	{
		$data = array('rw', 'posyandu', 'karang taruna', 'lpm', 'pkk', 'bpd', 'ecovillage palayangan');

		$this->response([
			    'status' => 'true',
                'data' => $data
        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function list_rw_post()
	{
		$post = $this->input->post(null, true);
		$data = $this->Custom_model->getdata('tbl_rw', array('id_desa' => $post['id_desa']));

		$this->response([
			    'status' => 'true',
                'data' => $data
        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function list_post()
	{
		$post = $this->input->post(null, true);

		if (!empty($post['kegiatan']) && !empty($post['id_desa'])) 
		{
			if (!empty($post['rw'])) 
			{
				$data = $this->Custom_model->getdata('tbl_kemajuan_desa', array('id_desa' => $post['id_desa'], 'kegiatan_kemajuan_desa' => $post['kegiatan'], 'id_rw' => $post['rw']));
			}
			else
			{
				$data = $this->Custom_model->getdata('tbl_kemajuan_desa', array('id_desa' => $post['id_desa'], 'kegiatan_kemajuan_desa' => $post['kegiatan']));
			}

			$this->response([
			    'status' => 'true',
                'data' => $data
        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => array('data' => 'kosong')
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function detail_post()
	{
		$post = $this->input->post(null, true);

		if (!empty($post['id_kemajuan_desa'])) 
		{
			$data = $this->Custom_model->getdetail('tbl_kemajuan_desa', array('id_kemajuan_desa' => $post['id_kemajuan_desa']));

			// $gallery = $this->Custom_model->getdata('tbl_kemajuan_desa', array('id_kemajuan_desa' => $post['id_kemajuan_desa']));


			$this->response([
			    'status' => 'true',
                'data' => $data
        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => array('data' => 'kosong')
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}
}