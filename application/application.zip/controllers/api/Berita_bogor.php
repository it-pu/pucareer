<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Berita_bogor extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function index_post()
	{
		$post = $this->input->post(null, true);

		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "http://bogor-kita.com/wp-json/wp/v2/posts?page=".$post['page'],
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_TIMEOUT => 60,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
		    "cache-control: no-cache"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		$response = json_decode($response, true);

		if (!empty($response)) 
		{
			// array of curl handles
			$multiCurl = array();
			// data to be returned
			$result = array();
			// multi handle
			$mh = curl_multi_init();
			foreach ($response as $i => $id) {
			  // URL from which data will be fetched
			  $fetchURL = $id['_links']['wp:featuredmedia'][0]['href'];
			  $multiCurl[$i] = curl_init();
			  curl_setopt($multiCurl[$i], CURLOPT_URL,$fetchURL);
			  curl_setopt($multiCurl[$i], CURLOPT_HEADER,0);
			  curl_setopt($multiCurl[$i], CURLOPT_RETURNTRANSFER,1);
			  curl_multi_add_handle($mh, $multiCurl[$i]);
			}
			$index=null;
			do {
			  curl_multi_exec($mh,$index);
			} while($index > 0);
			// get content and remove handles
			foreach($multiCurl as $k => $ch) {
			  $result[$k] = curl_multi_getcontent($ch);
			  $arraymed[$k] = json_decode($result[$k], true);
			  curl_multi_remove_handle($mh, $ch);
			}
			// close
			curl_multi_close($mh);

			foreach ($arraymed as $key => $value) 
			{
				$response[$key]['img_cover'] = $value['media_details']['sizes']['full']['source_url'];
			}

			$this->response([
				    'status' => 'true',
	                'data' => $response
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => array('data' => 'kosong')
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}

		

		// foreach ($response as $key => $value) 
		// {
		// 	$curlmed = curl_init();

		// 	curl_setopt_array($curlmed, array(
		// 	  CURLOPT_URL => $value['_links']['wp:featuredmedia'][0]['href'],
		// 	  CURLOPT_RETURNTRANSFER => true,
		// 	  CURLOPT_TIMEOUT => 60,
		// 	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		// 	  CURLOPT_CUSTOMREQUEST => "GET",
		// 	  CURLOPT_HTTPHEADER => array(
		// 	    "cache-control: no-cache"
		// 	  ),
		// 	));

		// 	$responsemed = curl_exec($curlmed);
		// 	$errmed = curl_error($curlmed);

		// 	curl_close($curlmed);

		// 	$responsemed = json_decode($responsemed, true);

		// 	if (empty($responsemed['media_details'])) 
		// 	{
		// 		$response[$key]['img_cover'] = 'false';
		// 	}
		// 	else
		// 	{
		// 		$response[$key]['img_cover'] = $responsemed['media_details']['sizes']['medium']['source_url'];
		// 	}

			
		// }

		
	}
}