<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Toko extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function index_post()
	{
		$post = $this->input->post(NULL, TRUE);

		$iddesa = null;
		$idtoko = null;

		if (!empty($post['id_toko'])) 
		{
			$idtoko = $post['id_toko'];
		}
		if (!empty($post['id_desa'])) 
		{
			$iddesa = $post['id_desa'];
		}

		$data = $this->Custom_model->gettoko($idtoko, $iddesa);

		$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function my_toko_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_user'])) 
		{
			$data = $this->Custom_model->gettoko(null, null, $post['id_user']);

			if (empty($data)) 
			{
				$this->response([
				    'status' => 'true',
	                'data' => array()
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
				    'status' => 'true',
	                'data' => $data
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'User ID Not Found'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function input_toko_post()
	{
		$this->load->library('upload');
		$this->load->library('image_lib');
		$post = $this->input->post(NULL, TRUE);

		$id_desa = $this->Custom_model->getdetail('tbl_user', array('id_user' => $post['id_user']));

		$insert = array
					(
						'id_desa' => $id_desa['id_desa'],
						'id_user' => $post['id_user'],
						'nama_toko' => $post['nama_toko'],
						'no_hp_toko' => $post['no_hp_toko'],
						'deskripsi_toko' => $post['deskripsi_toko'],
						'tgl_toko_request' => date('Y-m-d'),
						'status_toko' => 'memohon'
					);
		$id = $this->Custom_model->insertdata('tbl_toko', $insert);

		$error = array();
		foreach ($_FILES['foto_toko']["name"] as $kkey => $kvalue) 
		{	
			//UPLOAD PRODUK FOTO
			if (!empty($kvalue)) 
			{ 
				$_FILES['file']['name']     = $_FILES['foto_toko']['name'][$kkey];
			    $_FILES['file']['type']     = $_FILES['foto_toko']['type'][$kkey];
			    $_FILES['file']['tmp_name'] = $_FILES['foto_toko']['tmp_name'][$kkey];
			    $_FILES['file']['error']     = $_FILES['foto_toko']['error'][$kkey];
			    $_FILES['file']['size']     = $_FILES['foto_toko']['size'][$kkey];

				//MENGEDIT CONFIG UNTUK UPLOAD FOTO
				$config['file_name'] = uniqid().".".get_ext($_FILES['foto_toko']['name'][$kkey]);
				$config['upload_path'] = './files/toko';
				$config['allowed_types'] = 'jpg|jpeg|png';
				
				//MENGUPLOAD FOTO
				$this->upload->initialize($config);
				if ($this->upload->do_upload('file')) 
				{
					$gbr = $this->upload->data();
	                //Compress Image
	                $config['image_library']='gd2';
	            	$config['source_image']='./files/toko/'.$gbr['file_name'];
	            	$config['new_image']= './files/toko/'.$gbr['file_name'];
	            	$link_file = 'files/toko/'.$config['file_name'];

	            	list($width, $height) = getimagesize($config['source_image']);
					if ($width < $height) {
					    $config['master_dim'] = 'width';
					    $config['x_axis'] = 0;
					    $config['y_axis'] = 105 * ($height / $width - 1);
					}
					else {
					    $config['master_dim'] = 'height';
					    $config['x_axis'] = 105 * ($width / $height - 1);
					    $config['y_axis'] = 0;
					}
					$config['width'] = 500;
					$config['height'] = 500;

	                $config['create_thumb']= FALSE;
	                $config['maintain_ratio']= TRUE;

	                $this->image_lib->initialize($config);
					$this->image_lib->resize();
					$config['maintain_ratio'] = false;
					$this->image_lib->crop();

	                $insertfot = array
	                			(
	                				'id_toko' => $id,
	                				'link_file_toko_foto' => $link_file
	                			);

	                $id_foto_pro = $this->Custom_model->insertdata('tbl_toko_foto', $insertfot);

	                if ($kkey == 0) 
	            	{
	            		$this->Custom_model->updatedata('tbl_toko', array('id_foto_cover' => $id_foto_pro), array('id_toko' => $id));
	            	}
				}
				else
				{
					$error[] = $this->upload->display_errors();
				}
			}
		}

		$this->response([
				    'status' => 'true',
	                'data' => 'Submit Success'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
	}

	public function gallery_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (empty($post['id_toko'])) 
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'ID Not Found'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$gallery = $this->Custom_model->getdata('tbl_toko_foto', array('id_toko' => $post['id_toko']));

			if (empty($gallery)) 
			{
				$this->response([
				    'status' => 'true',
	                'data' => array()
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
				    'status' => 'true',
	                'data' => $gallery
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
	}

	public function produk_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_toko'])) 
		{
			$produk = $this->Custom_model->getproduk($post['id_toko']);

			if (empty($produk)) 
			{
				$this->response([
				    'status' => 'true',
	                'data' => array()
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
				    'status' => 'true',
	                'data' => $produk
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'ID Not Found'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function produk_ins_post()
	{
		$this->load->library('upload');
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_toko'] && !empty($post['nama_produk']))) 
		{
			$insert = array
					(
						'id_toko' => $post['id_toko'],
						'nama_produk' => $post['nama_produk'],
						'deskripsi_produk' => $post['deskripsi_produk'],
						'harga_produk' => rupiah_to_sql($post['harga_produk']),
						'tgl_upload_produk' => date('Y-m-d'),
						'status_produk' => 'aktif'
					);
			$id = $this->Custom_model->insertdata('tbl_toko_produk', $insert);

			$error = 0;
			foreach ($_FILES['foto_produk']["name"] as $kkey => $kvalue) 
			{	
				//UPLOAD PRODUK FOTO
				if (!empty($kvalue)) 
				{ 
					$_FILES['file']['name']     = $_FILES['foto_produk']['name'][$kkey];
				    $_FILES['file']['type']     = $_FILES['foto_produk']['type'][$kkey];
				    $_FILES['file']['tmp_name'] = $_FILES['foto_produk']['tmp_name'][$kkey];
				    $_FILES['file']['error']     = $_FILES['foto_produk']['error'][$kkey];
				    $_FILES['file']['size']     = $_FILES['foto_produk']['size'][$kkey];

					//MENGEDIT CONFIG UNTUK UPLOAD FOTO
					$config['file_name'] = uniqid().".".get_ext($_FILES['foto_produk']['name'][$kkey]);
					$config['upload_path'] = './files/pro';
					$config['allowed_types'] = 'jpg|jpeg|png';
					
					//MENGUPLOAD FOTO
					$this->upload->initialize($config);
					if ($this->upload->do_upload('file')) 
					{
						$gbr = $this->upload->data();
		                //Compress Image
		                $config['image_library']='gd2';
		            	$config['source_image']='./files/pro/'.$gbr['file_name'];
		            	$config['new_image']= './files/pro/'.$gbr['file_name'];
		            	$link_file = 'files/pro/'.$config['file_name'];

		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= TRUE;
		                $config['width']= 800;
		                $config['height']= 800;

		                $this->load->library('image_lib', $config);
		                $this->image_lib->resize();

		                $insertfot = array
		                			(
		                				'id_toko_produk' => $id,
		                				'link_file_produk_foto' => $link_file
		                			);

		                $id_foto_pro = $this->Custom_model->insertdata('tbl_toko_produk_foto', $insertfot);

		                if ($kkey == 0) 
		            	{
		            		$this->Custom_model->updatedata('tbl_toko_produk', array('id_cover_produk_foto' => $id_foto_pro), array('id_toko_produk' => $id));
		            	}
					}
					else
					{
						$error = $this->upload->display_errors();
					}
				}
			}

			$this->response([
				    'status' => 'true',
	                'data' => 'Upload Success'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'Please Check your Data'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function gallery_produk_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (empty($post['id_produk'])) 
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'ID Not Found'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
		else
		{
			$gallery = $this->Custom_model->getdata('tbl_toko_produk_foto', array('id_toko_produk' => $post['id_produk']));

			if (empty($gallery)) 
			{
				$this->response([
				    'status' => 'true',
	                'data' => array()
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
				    'status' => 'true',
	                'data' => $gallery
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
	}
}