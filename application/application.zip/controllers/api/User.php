<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class User extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('template_helper'));
		$this->load->library(array('form_validation', 'session'));
		$this->load->model('Custom_model');
	}

	public function login_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['no_hp']) && !empty($post['password'])) 
		{
			$cekuser = $this->Custom_model->getdetail('tbl_user', array('no_hp_user' => $post['no_hp']));

			if (!empty($cekuser)) 
			{
				$cekuserrole = $this->Custom_model->getrolelogin($cekuser['id_user']);

				if (!empty($cekuserrole)) 
				{
					if (password_verify($post['password'], $cekuser['password_user'])) 
					{
						$getnamalevel = $this->Custom_model->getdetail('tbl_level', array('id_level' => $cekuserrole['id_level']));

						$data = array
								(
									'id_desa' => $cekuser['id_desa'],
									'id_user' => $cekuser['id_user'],
									'nama_user' => $cekuser['nama_user'],
									'foto_user' => $cekuser['foto_user'],
									'level' => $getnamalevel['nama_level']
								);

						$this->response([
						    'status' => 'true',
			                'data' => $data
			        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
					}
					else
					{
						$this->response([
						    'status' => 'false',
			                'data' => 'No user found'
			        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
					}
				}
				else
				{
					$this->response([
					    'status' => 'false',
		                'data' => 'No user found'
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
				}
			}
			else
			{
				$this->response([
					    'status' => 'false',
		                'data' => 'No user found'
		        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
				    'status' => 'false',
	                'data' => 'Error, please try again'
	        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}

		$data = $this->Custom_model->gettoko($idtoko, $iddesa);
	}

	public function detail_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_user'])) 
		{
			$detail = $this->Custom_model->getdetail('tbl_user', array('id_user' => $post['id_user']));

			if (!empty($detail)) 
			{
				$data = array
						(
							'nama_user' => $detail['nama_user'],
							'email_user' => $detail['email_user'],
							'pekerjaan_user' => $detail['pekerjaan_user'],
							'saldo_user' => 'Rp '.rupiah($detail['saldo_user'])
						);

				$this->response([
							    'status' => 'true',
				                'data' => $data
				        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
							    'status' => 'false',
				                'data' => 'No user found'
				        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
						    'status' => 'false',
			                'data' => 'No user found'
			        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}

	public function list_user_rt_post()
	{
		$post = $this->input->post(NULL, TRUE);

		if (!empty($post['id_user'])) 
		{
			$getrt = $this->Custom_model->getdetail('tbl_rt', array('id_user' => $post['id_user']));
			$data = $this->Custom_model->getuserrt($getrt['id_rt']);

			if (!empty($data)) 
			{
				$this->response([
							    'status' => 'true',
				                'data' => $data
				        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
			else
			{
				$this->response([
							    'status' => 'true',
				                'data' => array()
				        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
			}
		}
		else
		{
			$this->response([
						    'status' => 'false',
			                'data' => 'No user found'
			        	], \Restserver\Libraries\REST_Controller::HTTP_OK);
		}
	}
}