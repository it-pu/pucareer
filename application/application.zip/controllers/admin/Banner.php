<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends ADMIN_Controller {

	public function index()
	{
		$banner = $this->Custom_model->getdata('tbl_banner', NULL, 'sort_num', 'ASC');

		$data = array
				(
					'banner' => $banner
				);

		$this->load->view('admin/banner/list', $data);
	}

	public function store()
	{
		$post = $this->input->post(NULL, TRUE);

		$insertdata = array
					(
						'nama_banner' => $post['nama_banner'],
						'file_foto_banner' => 0,
						'sort_num' => 0,
						'created_at_banner' => date('Y-m-d')
					);

		$db = $this->Custom_model->insertdatafoto('tbl_banner', 'id_banner', 'file_foto_banner', 'banner', $insertdata);

		if ($db == TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/banner'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/banner'));
		}
	}

	public function edit()
	{
		$post = $this->input->post(NULL, TRUE);

		if (empty($_FILES['file_foto_banner']["name"])) 
		{
			$insertdata = array
					(
						'nama_banner' => $post['nama_banner'],
					);

			$this->Custom_model->updatedata('tbl_banner', $insertdata, array('id_banner' => $post['id_banner']));

			$this->session->set_flashdata('success', 'Data has been edited');
    		redirect(base_url('admin/banner'));
		}
		else
		{
			$updatedata = array
					(
						'nama_banner' => $post['nama_banner'],
						'file_foto_banner' => 0
					);

			$db = $this->Custom_model->insertdatafoto('tbl_banner', 'id_banner', 'file_foto_banner', 'banner', $insertdata, $post['id_banner'], TRUE);

			if ($db == TRUE) 
			{
				$this->session->set_flashdata('success', 'Data has been edited');
	    		redirect(base_url('admin/banner'));
			}
			else
			{
				$this->session->set_flashdata('error', 'Error, please try again');
	    		redirect(base_url('admin/banner'));
			}
		}
	}

	public function delete($id_banner)
	{
		$getfoto = $this->Custom_model->getdetail('tbl_banner', array('id_banner' => $id_banner));

		unlink('./'.$getfoto['file_foto_banner']);

		$this->Custom_model->deletedata('tbl_banner', array('id_banner' => $id_banner));

		$this->session->set_flashdata('success', 'Data has been Deleted');
    	redirect(base_url('admin/banner/'));
	}

	public function update_sort()
	{
		$post = $this->input->post(NULL, TRUE);

		foreach ($post['positions'] as $position) 
		{
			$index = $position[0];
			$new_pos = $position[1];
			$this->Custom_model->updatedata('tbl_banner', array('sort_num' => $new_pos), array('id_banner' => $index));
		}

		exit('success');
	}

	public function get_edit_banner($id_banner)
	{
		$detail = $this->Custom_model->getdetail('tbl_banner', array('id_banner' => $id_banner));

		echo json_encode($detail);
	}
}