<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggaran extends ADMIN_Controller {

  public function index()
  {
    $anggaran = $this->Custom_model->getanggaran($this->sess['id_desa']);

    $data = array
        (
          'anggaran' => $anggaran
        );

    $this->load->view('admin/anggaran/list', $data);
  }

  public function add()
  {
    $this->load->view('admin/desa/add');
  }

  public function upload_anggaran()
  {
    $post = $this->input->post(NULL, TRUE);

    $insert = array
        (
          'id_desa' => $this->sess['id_desa'],
          'id_user' => $this->sess['id_user'],
          'nama_anggaran' => $post['nama'],
          'tgl_upload_anggaran' => date('Y-m-d H:i:s')
        );

    $db = $this->Custom_model->insertdatafoto('tbl_anggaran', 'id_anggaran', 'link_file_anggaran', 'an', $insert, false, null, null, true);

    if ($db === TRUE) 
    {
      $this->session->set_flashdata('success', 'New Data has been added');
        redirect(base_url('admin/anggaran'));
    }
    else
    {
      $this->session->set_flashdata('error', $db);
      redirect(base_url('admin/anggaran/add'));
    }
  }
}
