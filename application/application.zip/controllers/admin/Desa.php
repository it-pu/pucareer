<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Desa extends ADMIN_Controller {

	public function index()
	{
		$desa = $this->Custom_model->getdata('tbl_desa');

		$data = array
				(
					'desa' => $desa
				);

		$this->load->view('admin/desa/list', $data);
	}

	public function add()
	{
		$this->load->view('admin/desa/add');
	}

	public function store()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'nama_desa' => $post['nama_desa'],
					'alamat_desa' => $post['alamat_desa'],
					'kepala_desa' => $post['kepala_desa'],
					'tgl_aktif_desa' => date('Y-m-d')
				);

		$db = $this->Custom_model->insertdatafoto('tbl_desa', 'id_desa', 'logo_desa','logo_desa', $insert);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/desa'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/desa/add'));
		}
	}
}
