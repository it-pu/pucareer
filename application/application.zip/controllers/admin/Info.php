<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Info extends ADMIN_Controller {

	public function covid()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'covid'));

		$data = array
				(
					'data' => $detail
				);

		$this->load->view('admin/info/covid', $data);
	}

	public function anggaran()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'anggaran'));

		$data = array
				(
					'data' => $detail
				);

		$this->load->view('admin/info/anggaran', $data);
	}

	public function bansos()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'bansos'));

		$data = array
				(
					'data' => $detail
				);

		$this->load->view('admin/info/bansos', $data);
	}

	public function dpt()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'dpt'));

		$data = array
				(
					'data' => $detail
				);

		$this->load->view('admin/info/dpt', $data);
	}

	public function umkm()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'umkm'));

		$data = array
				(
					'data' => $detail
				);

		$this->load->view('admin/info/umkm', $data);
	}

	public function profil_desa()
	{
		$detail = $this->Custom_model->getdetail('tbl_setting', array('nama_setting' => 'profil_desa'));

		$data = array
				(
					'data' => $detail
				);

		$this->load->view('admin/info/profil_desa', $data);
	}

	public function store()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'judul_berita' => strtoupper($post['judul_berita']),
					'sumber_berita' => $post['sumber'],
					'link_berita' => $post['link_berita'],
					'isi_berita' => $post['isi_berita'],
					'status_berita' => 'aktif',
					'created_at_berita' => date('Y-m-d')
				);

		$db = $this->Custom_model->insertdatafoto('tbl_berita', 'id_berita', 'cover_berita', 'berita', $insert);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/berita'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/berita/add'));
		}
	}

	public function detail($id_berita)
	{
		$detail = $this->Custom_model->getdetail('tbl_berita', array('id_berita' => $id_berita));
		$getuser = $this->Custom_model->getdetail('tbl_user', array('id_user' => $detail['id_user']));
		$detail['nama_user'] = $getuser['nama_user'];

		$data = array
				(
					'detail' => $detail,
				);
		$this->load->view('admin/berita/detail', $data);
	}

	public function edit($setting)
	{
		$post = $this->input->post(NULL, TRUE);

		$update = array
				(
					'link_setting' => $post['link']
				);

		$this->Custom_model->updatedata('tbl_setting', $update, array('nama_setting' => $post['setting']));

		$this->session->set_flashdata('success', 'Data has been Edited');
		redirect(base_url('admin/info/').$post['setting']);
	}

	public function update()
	{
		$post = $this->input->post(NULL, TRUE);

		if (empty($_FILES['cover_berita']["name"])) 
		{
			$insertdata = array
					(
						'judul_berita' => strtoupper($post['judul_berita']),
						'sumber_berita' => $post['sumber'],
						'link_berita' => $post['link_berita'],
						'isi_berita' => $post['isi_berita']
					);

			$this->Custom_model->updatedata('tbl_berita', $insertdata, array('id_berita' => $post['id_berita']));

			$this->session->set_flashdata('success', 'Data has been Edited');
    		redirect(base_url('admin/berita/detail/').$post['id_berita']);
		}
		else
		{
			$updatedata = array
					(
						'judul_berita' => strtoupper($post['judul_berita']),
						'sumber_berita' => $post['sumber'],
						'link_berita' => $post['link_berita'],
						'isi_berita' => $post['isi_berita'],
						'cover_berita' => 0
					);


			$db = $this->Custom_model->insertdatafoto('tbl_berita', 'id_berita', 'cover_berita', 'berita', $updatedata, false, $post['id_berita'], TRUE);

			if ($db == TRUE) 
			{
				$this->session->set_flashdata('success', 'New Data has been edited');
	    		redirect(base_url('admin/berita/detail/').$post['id_berita']);
			}
			else
			{
				$this->session->set_flashdata('error', 'Error, please try again');
	    		redirect(base_url('admin/berita/edit/').$post['id_berita']);
			}
		}
	}

	public function aktif($id_berita, $list = null)
	{
		$this->Custom_model->updatedata('tbl_berita', array('status_berita' => 'aktif'), array('id_berita' => $id_berita));

		$this->session->set_flashdata('success', 'Data has been Edited');

		if ($list == 1) 
		{
			redirect(base_url('admin/berita'));
		}
		else
		{
			redirect(base_url('admin/berita/detail/').$id_berita);
		}
	}

	public function non_aktif($id_berita, $list = null)
	{
		$this->Custom_model->updatedata('tbl_berita', array('status_berita' => 'non aktif'), array('id_berita' => $id_berita));

		$this->session->set_flashdata('success', 'Data has been Edited');

		if ($list == 1) 
		{
			redirect(base_url('admin/berita'));
		}
		else
		{
			redirect(base_url('admin/berita/detail/').$id_berita);
		}
	}

	public function delete($id_berita)
	{
		$getfoto = $this->Custom_model->getdetail('tbl_berita', array('id_berita' => $id_berita));

		unlink('./'.$getfoto['cover_berita']);

		$this->Custom_model->deletedata('tbl_berita', array('id_berita' => $id_berita));

		$this->session->set_flashdata('success', 'Data has been Deleted');
    	redirect(base_url('admin/berita'));
	}
}
