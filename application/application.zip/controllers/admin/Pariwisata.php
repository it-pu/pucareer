<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pariwisata extends ADMIN_Controller {

  public function index()
  {
    $pariwisata = $this->Custom_model->getdata('tbl_pariwisata', array('id_desa' => $this->sess['id_desa']));

    $data = array
        (
          'pariwisata' => $pariwisata
        );

    $this->load->view('admin/pariwisata/list', $data);
  }

  public function add()
  {
    $this->load->view('admin/pariwisata/add');
  }

  public function store()
  {
    $post = $this->input->post(NULL, TRUE);

    $insert = array
        (
          'id_desa' => $this->sess['id_desa'],
          'id_user' => $this->sess['id_user'],
          'nama_pariwisata' => $post['nama_pariwisata'],
          'deskripsi_pariwisata' => $post['deskripsi_pariwisata'],
          'alamat_pariwisata' => $post['alamat_pariwisata'],
          'deskripsi_harga' => $post['deskripsi_harga'],
          'no_telp_pengurus' => $post['no_telp_pengurus'],
          'status_pariwisata' => 'buka',
          'tgl_upload_pariwisata' => date('Y-m-d H:i:s')
        );

    $db = $this->Custom_model->insertdatafoto('tbl_pariwisata', 'id_pariwisata', 'cover_pariwisata', 'par', $insert);

    if ($db === TRUE) 
    {
      $this->session->set_flashdata('success', 'New Data has been added');
        redirect(base_url('admin/pariwisata'));
    }
    else
    {
      $this->session->set_flashdata('error', $db);
        redirect(base_url('admin/pariwisata/add'));
    }
  }

  public function detail($id_pariwisata)
  {
    $detail = $this->Custom_model->getdetail('tbl_pariwisata', array('id_pariwisata' => $id_pariwisata));
    $gallery = $this->Custom_model->getdata('tbl_pariwisata_foto', array('id_pariwisata' => $id_pariwisata));

    $data = array
        (
          'detail' => $detail,
          'gallery' => $gallery
        );

    $this->load->view('admin/pariwisata/detail', $data);
  }

  public function add_foto()
  {
    $post = $this->input->post(NULL, TRUE);

    $insert = array
        (
          'id_pariwisata' => $post['id_pariwisata'],
          'deskripsi_foto_pariwisata' => $post['deskripsi_foto_pariwisata']
        );

    $db = $this->Custom_model->insertdatafoto('tbl_pariwisata_foto', 'id_pariwisata_foto', 'pariwisata_foto', 'galpar', $insert);

    if ($db === TRUE) 
    {
      $this->session->set_flashdata('success', 'New Data has been added');
        redirect(base_url('admin/pariwisata/detail/').$post['id_pariwisata']);
    }
    else
    {
      $this->session->set_flashdata('error', 'Please try again');
      redirect(base_url('admin/pariwisata/detail/').$post['id_pariwisata']);
    }
  }

  public function buka($id_pariwisata, $list = null)
  {
    $this->Custom_model->updatedata('tbl_pariwisata', array('status_pariwisata' => 'buka'), array('id_pariwisata' => $id_pariwisata));

    $this->session->set_flashdata('success', 'Data has been Edited');

    if ($list == 1) 
    {
      redirect(base_url('admin/pariwisata'));
    }
    else
    {
      redirect(base_url('admin/pariwisata/detail/').$id_pariwisata);
    }
  }

  public function tutup($id_pariwisata, $list = null)
  {
    $this->Custom_model->updatedata('tbl_pariwisata', array('status_pariwisata' => 'tutup'), array('id_pariwisata' => $id_pariwisata));

    $this->session->set_flashdata('success', 'Data has been Edited');

    if ($list == 1) 
    {
      redirect(base_url('admin/pariwisata'));
    }
    else
    {
      redirect(base_url('admin/pariwisata/detail/').$id_pariwisata);
    }
  }

  public function delete($id_berita)
  {
    $getfoto = $this->Custom_model->getdetail('tbl_berita', array('id_berita' => $id_berita));

    unlink('./'.$getfoto['cover_berita']);

    $this->Custom_model->deletedata('tbl_berita', array('id_berita' => $id_berita));

    $this->session->set_flashdata('success', 'Data has been Deleted');
      redirect(base_url('admin/berita'));
  }
}
