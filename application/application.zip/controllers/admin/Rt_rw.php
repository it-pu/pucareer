<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rt_rw extends ADMIN_Controller {

	public function daftar_rw()
	{
		$rw = $this->Custom_model->getrw($this->sess['id_desa']);

		$listuser = $this->Custom_model->getusersupmember($this->sess['id_desa']);

		$data = array
				(
					'rw' => $rw,
					'user' => $listuser
				);

		$this->load->view('admin/rtrw/list_rw', $data);
	}

	public function add_rw()
	{
		$post = $this->input->post(NULL, TRUE);

		$id_user = $post['id_user'] == '' ? 0 : $post['id_user'];

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'nomor_rw' => $post['nomor_rw'],
					'id_user' => $id_user,
					'tgl_input_rw' => date('Y-m-d')
				);
		$id_rw = $this->Custom_model->insertdata('tbl_rw', $insert);
		$this->Custom_model->updatedata('tbl_user', array('id_rw' => 0), array('id_rw' => $id_rw));

		$updateuser = $this->Custom_model->updatedata('tbl_user', array('id_rw' => $id_rw), array('id_user' => $post['id_user']));

		$this->session->set_flashdata('success', 'New Data has been added');
    	redirect(base_url('admin/rt_rw/daftar_rw'));
	}

	public function edit_rw_pj()
	{
		$post = $this->input->post(NULL, TRUE);

		$this->Custom_model->updatedata('tbl_rw', array('id_user' => $post['id_user']), array('id_rw' => $post['id_rw']));

		$updateuser = $this->Custom_model->updatedata('tbl_user', array('id_rw' => $post['id_rw']), array('id_user' => $post['id_user']));

		$this->session->set_flashdata('success', 'Data has been edited');
    	redirect(base_url('admin/rt_rw/daftar_rw'));
	}

	public function daftar_rt()
	{
		$rt = $this->Custom_model->getrt($this->sess['id_desa']);

		$listuser = $this->Custom_model->getusersupmember($this->sess['id_desa']);
		$rw = $this->Custom_model->getrw($this->sess['id_desa']);

		$data = array
				(
					'rt' => $rt,
					'rw' => $rw,
					'user' => $listuser
				);

		$this->load->view('admin/rtrw/list_rt', $data);
	}

	public function add_rt()
	{
		$post = $this->input->post(NULL, TRUE);

		$id_user = $post['id_user'] == '' ? 0 : $post['id_user'];

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'id_rw' => $post['id_rw'],
					'nomor_rt' => $post['nomor_rt'],
					'id_user' => $id_user,
					'tgl_input_rt' => date('Y-m-d')
				);
		$id_rt = $this->Custom_model->insertdata('tbl_rt', $insert);

		$updateuser = $this->Custom_model->updatedata('tbl_user', array('id_rt' => $id_rt), array('id_user' => $post['id_user']));

		$this->session->set_flashdata('success', 'New Data has been added');
    	redirect(base_url('admin/rt_rw/daftar_rt'));
	}

	public function get_rt($id_rw)
	{
		$data = $this->Custom_model->getdata('tbl_rt', array('id_rw' => $id_rw));

		echo json_encode($data);
	}

	public function edit_rt_pj()
	{
		$post = $this->input->post(NULL, TRUE);

		$this->Custom_model->updatedata('tbl_rt', array('id_user' => $post['id_user']), array('id_rt' => $post['id_rt']));

		$updateuser = $this->Custom_model->updatedata('tbl_user', array('id_rt' => $post['id_rt'], 'id_rw' => $post['id_rw']), array('id_user' => $post['id_user']));

		$this->session->set_flashdata('success', 'Data has been edited');
    	redirect(base_url('admin/rt_rw/daftar_rt'));
	}

	public function add()
	{
		$this->load->view('admin/desa/add');
	}
}
