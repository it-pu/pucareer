<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Toko extends ADMIN_Controller {

	public function index()
	{
		$toko = $this->Custom_model->gettoko(null, $this->sess['id_desa']);
		// echo $this->db->last_query();

		$data = array
				(
					'toko' => $toko
				);

		$this->load->view('admin/toko/list', $data);
	}

	public function buka($id_toko, $list = 0)
	{
		$this->Custom_model->updatedata('tbl_toko', array('tgl_toko_disetujui' => date('Y-m-d'), 'status_toko' => 'buka'), array('id_toko' => $id_toko));

		$this->session->set_flashdata('success', 'Toko telah <b>dibuka</b>');

		if ($list == 1) 
		{
			redirect(base_url('admin/toko'));
		}
		else
		{
			redirect(base_url('admin/toko/detail/').$id_toko);
		}
	}

	public function tolak($id_toko, $list = 0)
	{
		$this->Custom_model->updatedata('tbl_toko', array('tgl_toko_ditolak' => date('Y-m-d'), 'status_toko' => 'ditolak'), array('id_toko' => $id_toko));

		$this->session->set_flashdata('success', 'Toko telah <b>ditolak</b>');

		if ($list == 1) 
		{
			redirect(base_url('admin/toko'));
		}
		else
		{
			redirect(base_url('admin/toko/detail/').$id_toko);
		}
	}

	public function block($id_toko, $list = 0)
	{
		$this->Custom_model->updatedata('tbl_toko', array('status_toko' => 'block'), array('id_toko' => $id_toko));

		$this->session->set_flashdata('success', 'Toko telah <b>diblock</b>');

		if ($list == 1) 
		{
			redirect(base_url('admin/toko'));
		}
		else
		{
			redirect(base_url('admin/toko/detail/').$id_toko);
		}
	}

	public function detail($id_toko)
	{
		$detail = $this->Custom_model->gettoko($id_toko);
		$gallery = $this->Custom_model->getdata('tbl_toko_foto', array('id_toko' => $id_toko));

		$produk = $this->Custom_model->getproduk($id_toko);

		$data = array
				(
					'detail' => $detail,
					'gallery' => $gallery,
					'produk' => $produk
				);
		$this->load->view('admin/toko/detail', $data);
	}

	public function edit($id_toko)
	{
		$detail = $this->Custom_model->gettoko($id_toko);

		$data = array
				(
					'detail' => $detail
				);
		$this->load->view('admin/toko/edit', $data);
	}
}
