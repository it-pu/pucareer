<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat extends ADMIN_Controller {

	public function index()
	{
		$surat = $this->Custom_model->getsurat($this->sess['id_desa']);

		$data = array
				(
					'surat' => $surat
				);

		$this->load->view('admin/surat/list', $data);
	}

	public function detail($id_surat)
	{
		$surat = $this->Custom_model->getsurat(null, $id_surat);

		$file = $this->Custom_model->getdata('tbl_surat_syarat_file', array('id_surat' => $surat['id_surat']));

		$data = array
				(
					'detail' => $surat,
					'file' => $file
				);

		$this->load->view('admin/surat/detail', $data);
	}

	public function kategori()
	{
		$kategori = $this->Custom_model->getdata('tbl_surat_kategori', array('id_desa' => $this->sess['id_desa']));

		$data = array
				(
					'kategori' => $kategori
				);

		$this->load->view('admin/surat/list_kategori', $data);
	}

	public function sub_kategori()
	{
		$skategori = $this->Custom_model->getsuratsub(null, $this->sess['id_desa']);

		$data = array
				(
					'skategori' => $skategori
				);

		$this->load->view('admin/surat/list_sub_kategori', $data);
	}

	public function add_sub_kategori()
	{
		$kategori = $this->Custom_model->getdata('tbl_surat_kategori', array('id_desa' => $this->sess['id_desa']));

		$data = array
				(
					'kategori' => $kategori
				);

		$this->load->view('admin/surat/add_sub_kategori', $data);
	}

	public function add_kategori()
	{
		$this->load->view('admin/surat/add_kategori');
	}

	public function edit_kategori($id_surat_kategori)
	{
		$kategori = $this->Custom_model->getdetail('tbl_surat_kategori', array('id_surat_kategori' => $id_surat_kategori));

		$data = array
				(
					'kategori' => $kategori
				);

		$this->load->view('admin/surat/edit_kategori', $data);
	}

	public function edit_sub_kategori($id_surat_kategori_sub)
	{
		$kategori = $this->Custom_model->getdata('tbl_surat_kategori', array('id_desa' => $this->sess['id_desa']));
		$skategori = $this->Custom_model->getdetail('tbl_surat_kategori_sub', array('id_surat_kategori_sub' => $id_surat_kategori_sub));

		$data = array
				(
					'skategori' => $skategori,
					'kategori' => $kategori
				);

		$this->load->view('admin/surat/edit_sub_kategori', $data);
	}

	public function store_kategori()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'id_user_penambah_kategori' => $this->sess['id_user'],
					'nama_kategori_surat' => ucwords($post['nama_kategori']),
					'deskripsi_kategori_surat' => $post['deskripsi_kategori'],
					'syarat_surat' => '',
					'tgl_tambah_kategori_surat' => date('Y-m-d H:i:s')
				);

		$db = $this->Custom_model->insertdata('tbl_surat_kategori', $insert);

		if ($db == TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/surat/kategori'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/surat/add_kategori'));
		}
	}

	public function store_sub_kategori()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'id_surat_kategori' => $post['kategori'],
					'nama_surat_kategori_sub' => ucwords($post['nama_sub_kategori']),
					'deskripsi_surat_kategori_sub' => $post['deskripsi'],
					'syarat_sub_kategori' => $post['syarat'],
					'tgl_upload_kat_sub' => date('Y-m-d H:i:s')
				);

		$db = $this->Custom_model->insertdata('tbl_surat_kategori_sub', $insert);

		if ($db == TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/surat/sub_kategori'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/surat/add_sub_kategori'));
		}
	}

	public function update_kategori()
	{
		$post = $this->input->post(NULL, TRUE);

		$update = array
				(
					'nama_kategori_surat' => $post['nama_kategori'],
					'deskripsi_kategori_surat' => $post['deskripsi_kategori']
				);

		$db = $this->Custom_model->updatedata('tbl_surat_kategori', $update, array('id_surat_kategori' => $post['id_surat_kategori']));

		$this->session->set_flashdata('success', 'Data has been edited');
    	redirect(base_url('admin/surat/kategori'));
	}

	public function update_sub_kategori()
	{
		$post = $this->input->post(NULL, TRUE);

		$update = array
				(
					'nama_surat_kategori_sub' => ucwords($post['nama_sub_kategori']),
					'deskripsi_surat_kategori_sub' => $post['deskripsi'],
					'syarat_sub_kategori' => $post['syarat']
				);

		$db = $this->Custom_model->updatedata('tbl_surat_kategori_sub', $update, array('id_surat_kategori_sub' => $post['id_surat_kategori_sub']));

		$this->session->set_flashdata('success', 'Data has been edited');
    	redirect(base_url('admin/surat/sub_kategori'));
	}

	public function status($status, $id_surat_kategori)
	{
		$status_edit = $status == 'aktif' ? 'aktif' : 'non aktif';

		$this->Custom_model->updatedata('tbl_surat_kategori', array('status_surat_kategori' => $status_edit), array('id_surat_kategori' => $id_surat_kategori));

		$this->session->set_flashdata('success', 'Data has been edited');
    	redirect(base_url('admin/surat/kategori'));
	}

	public function kirim_surat()
	{
		$post = $this->input->post(NULL, TRUE);

		$db = $this->Custom_model->kirim_surat($post['id_surat']);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'Send File Success');
		}
		else
		{
			$this->session->set_flashdata('error', $db);
		}
		redirect(base_url('admin/surat'));
	}

	public function ambil_surat($id_surat, $list = null)
	{
		$post = $this->input->post(NULL, TRUE);

		$this->Custom_model->updatedata('tbl_surat', array('tgl_terima' => date('Y-m-d H:i:s'), 'status_surat' => 'diterima'), array('id_surat' => $id_surat));

		$this->session->set_flashdata('success', 'Edit Data Success');

		if ($list == null) 
		{
			redirect(base_url('admin/surat'));
		}
		else
		{
			redirect(base_url('admin/surat/detail/').$id_surat);
		}
	}

	public function tolak($id_surat, $list = null)
	{
		$post = $this->input->post(NULL, TRUE);

		$this->Custom_model->updatedata('tbl_surat', array('status_surat' => 'ditolak'), array('id_surat' => $id_surat));

		$this->session->set_flashdata('success', 'Edit Data Success');

		if ($list == null) 
		{
			redirect(base_url('admin/surat'));
		}
		else
		{
			redirect(base_url('admin/surat/detail/').$id_surat);
		}
	}

	public function add()
	{
		$this->load->view('admin/desa/add');
	}

	public function store()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'nama_desa' => $post['nama_desa'],
					'alamat_desa' => $post['alamat_desa'],
					'kepala_desa' => $post['kepala_desa'],
					'tgl_aktif_desa' => date('Y-m-d')
				);

		$db = $this->Custom_model->insertdatafoto('tbl_desa', 'id_desa', 'logo_desa','logo_desa', $insert);

		if ($db == TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/desa'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/desa/add'));
		}
	}

	public function edit_surat()
	{
		$post = $this->input->post(NULL, TRUE);

		$db = $this->Custom_model->editfileonly('tbl_surat', 'id_surat', 'link_file_surat', 'surat', $post['id_surat'], true, false);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'Data has been edited');
		}
		else
		{
			$this->session->set_flashdata('error', $db);
		}
		redirect(base_url('admin/surat/'));
	}
}
