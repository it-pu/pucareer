<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends ADMIN_Controller {

	public function index()
	{
		$laporan = $this->Custom_model->getlaporan(null, $this->sess['id_desa']);

		$data = array
				(
					'laporan' => $laporan
				);

		$this->load->view('admin/laporan/list', $data);
	}

	public function detail($id_laporan)
	{
		$laporan = $this->Custom_model->getlaporan($id_laporan);
		$gallery = $this->Custom_model->getdata('tbl_laporan_foto', array('id_laporan' => $id_laporan));

		$data = array
				(
					'detail' => $laporan,
					'gallery' => $gallery
				);

		$this->load->view('admin/laporan/detail', $data);
	}

	public function kirim_surat()
	{
		$post = $this->input->post(NULL, TRUE);

		$db = $this->Custom_model->kirim_surat($post['id_surat']);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'Send File Success');
		}
		else
		{
			$this->session->set_flashdata('error', $db);
		}
		redirect(base_url('admin/surat'));
	}

	public function add()
	{
		$this->load->view('admin/desa/add');
	}

	public function store()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'nama_desa' => $post['nama_desa'],
					'alamat_desa' => $post['alamat_desa'],
					'kepala_desa' => $post['kepala_desa'],
					'tgl_aktif_desa' => date('Y-m-d')
				);

		$db = $this->Custom_model->insertdatafoto('tbl_desa', 'id_desa', 'logo_desa','logo_desa', $insert);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/desa'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/desa/add'));
		}
	}

	public function edit_surat()
	{
		$post = $this->input->post(NULL, TRUE);

		$db = $this->Custom_model->editfileonly('tbl_surat', 'id_surat', 'link_file_surat', 'surat', $post['id_surat'], true, false);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'Data has been edited');
		}
		else
		{
			$this->session->set_flashdata('error', $db);
		}
		redirect(base_url('admin/surat/'));
	}
}
