<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bank_sampah extends ADMIN_Controller {

	public function transaksi()
	{
		$transaksi = $this->Custom_model->gettransaksi(null, $this->sess['id_user'], $this->sess['id_desa']);

		$data = array
				(
					'transaksi' => $transaksi
				);

		$this->load->view('admin/bank_sampah/transaksi', $data);
	}

	public function detailtransaksi($idtrans)
	{
		$transaksi = $this->Custom_model->gettransaksi($idtrans);
		$list = $this->Custom_model->gettransaksilist($idtrans);

		$op = $this->Custom_model->getdetail('tbl_user', array('id_user' => $transaksi['id_user_operator']));

		$data = array
				(
					'transaksi' => $transaksi,
					'list' => $list,
					'op' => $op['nama_user']
				);

		$this->load->view('admin/bank_sampah/detail_transaksi', $data);
	}

	public function add_transaksi()
	{
		$nasabah = $this->Custom_model->getdata('tbl_user', array('id_desa' => $this->sess['id_desa']));
		$jenissampah = $this->Custom_model->getdata('tbl_jenis_sampah', array('id_desa' => $this->sess['id_desa']));
		$lokasi = $this->Custom_model->getdata('tbl_lokasi_bs', array('id_desa' => $this->sess['id_desa']));

		$data = array
				(
					'nasabah' => $nasabah,
					'jenis_sampah' => $jenissampah,
					'lokasi' => $lokasi
				);

		$this->load->view('admin/bank_sampah/add_transaksi', $data);
	}

	public function store_transaksi()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'id_user_nasabah' => $post['nasabah'],
					'id_user_operator' => $this->sess['id_user'],
					'id_lokasi_bs' => $post['lokasi'],
					'tgl_transaksi_bs' => date('Y-m-d H:i:s'),
				);
		$idtrans = $this->Custom_model->insertdata('tbl_transaksi_bs', $insert);

		$totaltransaksiharga = 0;

		$insertisi = array();
		foreach ($post['jenis_sampah'] as $key => $value) 
		{
			if (!empty($value)) 
			{
				$findprice = $this->Custom_model->getdetail('tbl_jenis_sampah', array('id_jenis_sampah' => $value));
				$totalprice = $findprice['harga_jenis_sampah'] * $post['qty'][$key];

				$insertisi[$key] = array
							(
								'id_transaksi_bs' => $idtrans,
								'id_jenis_sampah' => $value,
								'quantity' => $post['qty'][$key],
								'total_harga_sampah' => $totalprice
							);

				$totaltransaksiharga += $totalprice;
			}
		}

		$this->Custom_model->insertdata('tbl_transaksi_isi_bs', $insertisi, FALSE, TRUE);

		$this->Custom_model->updatedata('tbl_transaksi_bs', array('total_saldo_didapat' => $totaltransaksiharga), array('id_transaksi_bs' => $idtrans));

		$getsaldoskrg = $this->Custom_model->getdetail('tbl_user', array('id_user' => $post['nasabah']));

		$newsaldo = $getsaldoskrg['saldo_user'] + $totaltransaksiharga;

		$this->Custom_model->updatedata('tbl_user', array('saldo_user' => $newsaldo), array('id_user' => $post['nasabah']));

		$this->session->set_flashdata('success', 'New Data has been added');
    	redirect(base_url('admin/bank_sampah/transaksi'));
	}

	public function jenis_sampah()
	{
		$jenis = $this->Custom_model->getdata('tbl_jenis_sampah', array('id_desa' => $this->sess['id_desa']));

		$data = array
				(
					'jenis' => $jenis
				);

		$this->load->view('admin/bank_sampah/jenis', $data);
	}

	public function add_jenis()
	{
		$this->load->view('admin/bank_sampah/add_jenis_sampah');
	}

	public function edit_jenis($id_jenis_sampah)
	{
		$jenis = $this->Custom_model->getdetail('tbl_jenis_sampah', array('id_jenis_sampah' => $id_jenis_sampah));

		$data = array
				(
					'jenis' => $jenis
				);

		$this->load->view('admin/bank_sampah/edit_jenis_sampah', $data);
	}

	public function store_jenis()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'id_user_penambah' => $this->sess['id_user'],
					'nama_jenis_sampah' => $post['nama'],
					'kode_jenis_sampah' => $post['kode'],
					'satuan_jenis_sampah' => $post['satuan'],
					'harga_jenis_sampah' => rupiah_to_sql($post['harga']),
					'tgl_tambah_jenis_sampah' => date('Y-m-d H:i:s')
				);

		$this->Custom_model->insertdata('tbl_jenis_sampah', $insert);

		$this->session->set_flashdata('success', 'New Data has been added');
    	redirect(base_url('admin/bank_sampah/jenis_sampah'));
	}

	public function update_jenis()
	{
		$post = $this->input->post(NULL, TRUE);

		$update = array
				(
					'nama_jenis_sampah' => $post['nama'],
					'kode_jenis_sampah' => $post['kode'],
					'satuan_jenis_sampah' => $post['satuan'],
					'harga_jenis_sampah' => rupiah_to_sql($post['harga'])
				);

		$this->Custom_model->updatedata('tbl_jenis_sampah', $update, array('id_jenis_sampah' => $post['id_jenis_sampah']));

		$this->session->set_flashdata('success', 'Data has been edited');
    	redirect(base_url('admin/bank_sampah/jenis_sampah'));
	}

	public function lokasi()
	{
		$lokasi = $this->Custom_model->getdata('tbl_lokasi_bs', array('id_desa' => $this->sess['id_desa']));

		$data = array
				(
					'lokasi' => $lokasi
				);

		$this->load->view('admin/bank_sampah/lokasi', $data);
	}

	public function add_lokasi()
	{
		$this->load->view('admin/bank_sampah/add_lokasi');
	}

	public function store_lokasi()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'nama_lokasi_bs' => $post['nama'],
					'alamat_bs' => $post['alamat'],
					'latitude_bs' => $post['lat'],
					'longitude_bs' => $post['lon'],
					'tgl_tambah_bs' => date('Y-m-d H:i:s')
				);

		$this->Custom_model->insertdata('tbl_lokasi_bs', $insert);

		$this->session->set_flashdata('success', 'New Data has been added');
    	redirect(base_url('admin/bank_sampah/lokasi'));
	}

	public function store()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'nama_desa' => $post['nama_desa'],
					'alamat_desa' => $post['alamat_desa'],
					'kepala_desa' => $post['kepala_desa'],
					'tgl_aktif_desa' => date('Y-m-d')
				);

		$db = $this->Custom_model->insertdatafoto('tbl_desa', 'id_desa', 'logo_desa','logo_desa', $insert);

		if ($db === TRUE) 
		{
			$this->session->set_flashdata('success', 'New Data has been added');
    		redirect(base_url('admin/desa'));
		}
		else
		{
			$this->session->set_flashdata('error', $db);
    		redirect(base_url('admin/desa/add'));
		}
	}

	public function reward()
	{
		$reward = $this->Custom_model->getdata('tbl_reward_bs', array('id_desa' => $this->sess['id_desa']));

		$data = array
				(
					'reward' => $reward
				);

		$this->load->view('admin/bank_sampah/reward', $data);
	}

	public function store_reward()
	{
		$post = $this->input->post(NULL, TRUE);

		$insert = array
				(
					'id_desa' => $this->sess['id_desa'],
					'id_user' => $this->sess['id_user'],
					'nama_reward' => $post['nama'],
					'nilai_dibutuhkan' => $post['nilai'],
					'qty_reward' => $post['qty'],
					'tgl_ditambahkan_reward' => date('Y-m-d H:i:s')
				);

		$db = $this->Custom_model->insertdata('tbl_reward_bs', $insert);

		$this->session->set_flashdata('success', 'New Data has been added');
		redirect(base_url('admin/bank_sampah/reward'));
	}

	public function edit_reward()
	{
		$post = $this->input->post(NULL, TRUE);

		$update = array
				(
					'nama_reward' => $post['nama'],
					'nilai_dibutuhkan' => $post['nilai'],
					'qty_reward' => $post['qty']
				);

		$db = $this->Custom_model->updatedata('tbl_reward_bs', $update, array('id_reward_bs' => $post['id_reward']));

		$this->session->set_flashdata('success', 'Data has been edited');
		redirect(base_url('admin/bank_sampah/reward'));
	}	

	public function trans_reward()
	{
		$trans = $this->Custom_model->getrewardtrans($this->sess['id_desa']);

		$data = array
				(
					'trans' => $trans
				);

		$this->load->view('admin/bank_sampah/trans_reward', $data);
	}

	public function edit_stat_trans($id_trans_reward)
	{
		$trans = $this->Custom_model->updatedata('tbl_transaksi_reward_bs', array('status_transaksi_reward' => 'sudah diambil'), array('id_transaksi_reward_bs' => $id_trans_reward));

		$this->session->set_flashdata('success', 'Data has been edited');
		redirect(base_url('admin/bank_sampah/trans_reward'));
	}
}
